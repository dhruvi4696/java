
public class TestInterfaceDemo
{
	public static void main(String args[])
	{	
		Printable p1= new Customer (222,"dhruvi");
		System.out.println(((Customer) p1).sayHi()); //down casting
	}
}
