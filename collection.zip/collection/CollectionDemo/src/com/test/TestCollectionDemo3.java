package com.test;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;


public class TestCollectionDemo3 
{
	public static void main(String[] args) 
	{
		Set<Employee> list = new TreeSet<Employee>(new EmployeeComparator());
		Employee e1 = new Employee(2001, "john",9000);
		Employee e2 = new Employee(2003, "radha",8000);
		Employee e3 = new Employee(2002, "amar",9000);
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		//Collections.sort(list,new EmployeeComparator());
		
		
		for(Object obj : list)
		{
			//type cast to string to get all behavior of string class.
			//Employee str =(Employee)obj;
			System.out.println(obj);
		}

	//list1.forEach(p->System.out.println(p));
	
	}
}
