
public class TestExceptionEmployee {

	public static void main(String[] args) {
		ExceptionEmployee s1 = new ExceptionEmployee();
		s1.setFirstName("");
		s1.setLastName("doshi");
		s1.setGender('F');
		
		ExceptionEmployee s2 = new ExceptionEmployee();
		s2.setFirstName("darsh");
		s2.setLastName("doshi");
		s2.setGender('F');
		
		ExceptionEmployee s3 = new ExceptionEmployee();
		s3.setFirstName("darsh");
		s3.setLastName("");
		s3.setGender('F');
	}

}
