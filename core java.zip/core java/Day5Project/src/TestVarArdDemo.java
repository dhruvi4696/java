class Calculator1
{
	public void add(String name,int ... nums)
	{
		int sum= 0;
		for(int temp:nums)
			{sum=sum+temp;
			}
		System.out.println(name +" sum : "+sum);
	}
}
public class TestVarArdDemo {

	public static void main(String[] args)
	{
		Calculator1 c= new Calculator1();
		c.add("dhruvi",10,70,90);
	}
}
