class GreetMe 
{
	public static void main(String aa[])
	{
		System.out.println("average!");
	}
}

public class Average
{
	public static void main(String aa[])
	{	
		int avg=0 ;
		
		for(int j=0;j<aa.length;j++)
		{ 	
			avg = avg + Integer.parseInt(aa[j]);
		}
		avg = avg/aa.length;
		System.out.println("the average is :" +avg);
	}
}


