//import Date class from javabasicprog project.
enum Gender
{
	M,F,Male , Female;
}

public class Person 
{
	private String panNo;
	private String perName;
	private float perSal;
	Date perDob;
	Gender  gender;
	
	public Person()
	{
		panNo="unknown";
		perName="unknown";
		perSal=0.0F;
		perDob=new Date();
	}
	
	public Person(String panNo, String perName, float perSal, Date perDob)
	{
		this.panNo=panNo;
		this.perName=perName;
		this.perSal=perSal;
		this.perDob=perDob;
	}
	
	public Person(String panNo, String perName, float perSal, Date perDob, Gender gender)
	{
		this.panNo=panNo;
		this.perName=perName;
		this.perSal=perSal;
		this.perDob=perDob;
		this.gender= gender;
	}
	
	public String dispPersonInfo()
	{
		return "Person Pan no: " + panNo +" , per name : " +perName +" , person salary : "+ perSal +", person dob is : "
	+perDob.dispDate() +" ,gender is :" + gender ;
	}
}
