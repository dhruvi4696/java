import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/*3.3: Create a method to accept date and
print the duration in days, months and years with regards to current system date.*/

public class DurationInDays
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);	
		System.out.print("Enter day: ");
		int day = sc.nextInt();	
		System.out.print("Enter month: ");
		int mon = sc.nextInt();	
		System.out.print("Enter year: ");
		int year = sc.nextInt();
		
		LocalDate date1 =  LocalDate.of(year,mon,day);
		LocalDate today=LocalDate.now();
		Period per=Period.between(date1, today);
		
		System.out.println("total days : "+per.getDays()+"\n   months: "+per.getMonths()
				 +"\n   years: "+per.getYears());
		sc.close();     
	}
}