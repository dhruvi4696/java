
public class Tablet extends Medicines
{
	String type;
	public Tablet(){
		super();
	}
	
	
	public Tablet(String medName, String cmpName, String expDate, float price,
			String type) 
	{
		super(medName, cmpName, expDate, price);
		this.type= type;
	}
	
	public String dispInfo()
	{
		return super.dispInfo()
		+  "\ntype : "+type +"\nStore at cool and dry place!";
	}
}
