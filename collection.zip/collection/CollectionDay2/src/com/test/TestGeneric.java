package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestGeneric 
{
	public static void print(List<String> list) throws MyException
	{
		if(list!= null && list.size()>0)
		{
		String str =list.get(list.size()-1);
		System.out.println(str);
		}
		else
			throw new MyException("list is empty");
	}
	
	public static List<String>  getAllElements(List<String> list)
	{
		ArrayList<String> list2 = new ArrayList<String>(); 
				
		for(String s: list)
		{
			list.add(s);
		}
		return list2;
	}
		
		
	public static void main(String[] args)
	{
		ArrayList<String> list =  new ArrayList<String>();
		List<String> mylist =  Arrays.asList("one","two","four");
		
		list.add("one");
		list.add("two");
		list.add("three");
		
		try{
			print(list);
		}
		catch(MyException me)
		{
			System.out.println(me.getMessage());
		}
		
		for(String s : list)
		{
			System.out.println(s);
		}
		
		for(String s : mylist)
		{
			System.out.println(s);
		}
		List<String> list3 =getAllElements(list);
		for(String str: list3)
		{
		System.out.println(str);
		}
	}
}
