
public class TestEmpArrayDemo
{
	private static String  city="Pune";
	
	public void method1(){
	System.out.println(city);
		
	}
	
	//static has to be use before main function.
	static
	{
		System.out.println("static block is invoked at when the classes are loaded at" +" memory by class loader");
	}
	
	public static void main(String[] args)
	{
		
		TestEmpArrayDemo vv = new TestEmpArrayDemo();
		vv.method1();
		
		Emp emps[]= new Emp[3];
		emps[0]= new Emp(111, "Smita", 2000);
		emps[1]= new Emp(112, "Dhruvi", 8000);
		emps[2]= new Emp(113, "Neha", 9000);
		
		
		for(int i =0 ;i<emps.length; i++)
		{
			System.out.println(i +"th Details " +emps[i].dispInfo());
			System.out.println(i +" Annual salary is " +emps[i].calcAnnualsal());
		}
		Emp.getCount();
	}
}
