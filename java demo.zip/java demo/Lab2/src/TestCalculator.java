class Calculator
{
	public void add(int num, int num2)
	{
		System.out.println("addition of 2 int  : "+(num+num2));
	}
	public void add(int num, int num2,int num3)
	{
		System.out.println("addition of 3 int : "+(num+num2+num3));
	}
	public void add(byte num, byte num2)
	{
		System.out.println("addition of 2 byte : "+(num+num2));
	}
	public void add(float num, float num2)
	{
		System.out.println("addition of 2 float : "+(num+num2));
	}
	public void add(double num, double num2)
	{
		System.out.println("addition of 2 double : "+(num+num2));
	}
	public void add(String num, String num2)
	{
		System.out.println("addition of 2 string : "+(num+" "+num2));
	}
	public void add(Integer num, Integer num2)
	{
		System.out.println("addition of 2 Int wrapper class : "+(num+num2));
	}
}
public class TestCalculator
{
	public static void main(String[] args)
	{
		Calculator obj = new Calculator();
		obj.add(10, 20);
		obj.add(10, 20,80);
		obj.add(10.0F, 20.0F);
		obj.add(10.0, 20.0);
		obj.add("kk", "kkl");
		obj.add('l', 'k');
		obj.add((byte)10,(byte) 20);
		obj.add((Integer)10,(Integer) 20);
	}
}
