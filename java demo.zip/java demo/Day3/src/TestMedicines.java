import java.util.Scanner;


public class TestMedicines {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size :");
		int size = sc.nextInt();
		
		Medicines med[]= new Medicines[size];
		for(int i=0; i<size;i++)
		{
			System.out.println("Type sy for syrup , on for ointment , tb for tablet :\n");
			String type = sc.next();
		
		switch(type)
		{
		case "tb": 
			System.out.print("Enter medicine name ");
			String mdnm = sc.next();
			
			System.out.print("Enter company name: ");
			String cmp = sc.next();
			
			System.out.print("Enter expiry date: ");
			String expdt= sc.next();	
			
			System.out.print("Enter price: ");
			float prc = sc.nextInt();
			
			 type = "tablet"; 
			 med[i] = new Tablet(mdnm, cmp, expdt,prc,type);
			 break;
					
		case "on":
			System.out.print("Enter medicine name ");
			 mdnm = sc.next();
			
			System.out.print("Enter company name: ");
			 cmp = sc.next();
			
			System.out.print("Enter expiry date: ");
			expdt= sc.next();	
			
			System.out.print("Enter price: ");
			prc = sc.nextInt();
			
			 type = "ointment"; 
			 med[i] = new Tablet(mdnm, cmp, expdt,prc,type);
			 break;
			
		case "sy":
			System.out.print("Enter medicine name ");
			 mdnm = sc.next();
			
			System.out.print("Enter company name: ");
			 cmp = sc.next();
			
			System.out.print("Enter expiry date: ");
			expdt= sc.next();	
			
			System.out.print("Enter price: ");
			prc = sc.nextInt();
			
			 type = "syrup"; 
			 med[i] = new Tablet(mdnm, cmp, expdt,prc,type);
			 break;
			
		default :
			System.out.println("wrong choice!");
		}

		System.out.println(med[i].dispInfo()+"\n");
		}
	}
	}

