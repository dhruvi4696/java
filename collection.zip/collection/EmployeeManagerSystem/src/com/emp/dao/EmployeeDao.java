package com.emp.dao;

import com.emp.bin.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeDao 
{
	public int addEmp(EmployeeBean bean) throws EmployeeException; 
}
