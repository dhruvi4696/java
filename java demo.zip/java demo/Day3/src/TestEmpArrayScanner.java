import java.util.Scanner;


public class TestEmpArrayScanner 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter size :");
		int size = sc.nextInt();
		Emp emps[]= new Emp[size];
		for(int i=0; i<size;i++)
		{
			System.out.println("Type sm for sales manager , emp for employee , we for wageemp :");
			String type = sc.next();
		
		switch(type)
		{
		case "sm": 
			System.out.print("Enter employee id: ");
			int empid = sc.nextInt();
			
			System.out.print("Enter employee name: ");
			String empnm = sc.next();
			
			System.out.print("Enter employee salary: ");
			float empsal= sc.nextInt();	
			
			System.out.print("Enter number of hours: ");
			int noofhr = sc.nextInt();
			
			System.out.print("Enter rate per hour : ");
			int  ratehr = sc.nextInt();
			
			System.out.print("Enter total sales: ");
			int sales= sc.nextInt();	
			
			System.out.print("Enter commision: ");
			float cmsn= sc.nextFloat();	
			
			 emps[i] = new SalsMgr( empid, empnm, empsal,noofhr,ratehr,sales,cmsn);
			 break;
					
		case "emp":
			System.out.print("Enter employee id: ");
			 empid = sc.nextInt();
			
			System.out.print("Enter employee name: ");
			 empnm = sc.next();
			
			System.out.print("Enter employee salary: ");
			empsal= sc.nextInt();	
			
			emps[i] = new Emp( empid, empnm, empsal);
			break;
			
		case "we":
			System.out.print("Enter employee id: ");
			empid = sc.nextInt();
			
			System.out.print("Enter employee name: ");
			empnm = sc.next();
			
			System.out.print("Enter employee salary: ");
			empsal= sc.nextInt();	
			
			System.out.print("Enter number of hours: ");
			noofhr = sc.nextInt();
			
			System.out.print("Enter rate per hour: ");
			ratehr = sc.nextInt();
			
			emps[i] = new WageEmp( empid, empnm, empsal,noofhr,ratehr);
			break;
			
		default :
			System.out.println("wrong choice!");
		}

		System.out.println("Employee["+i+"]" + emps[i].dispInfo()+"\n");
		}
	}
	}

