
public class Emp
{
	private int empId;
	private String empName;
	private float empSal;
	private static int count;
	
	public Emp()
	{
		
	}
	
	public static void getCount()
	{
		System.out.println("the count is : "+count);
	}
	
	public Emp(int empId , String empName , float empSal)
	{
		this.empId= empId;
		this.empName= empName;
		this.empSal= empSal;
		count++;
	}
	public String dispInfo()
	{
		return "emp [empid=" +empId +", name= "+empName+ ", basic salary is = "+empSal+ "]";
	}
	public float calcAnnualsal()
	{
		return empSal*12;
	}
}
