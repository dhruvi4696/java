class GreetMe 
{
	public static void main(String aa[])
	{
		System.out.println("welcome to capgemini!");
	}
}

public class Welcome
{
	public static void main(String aa[])
	{
		String name =aa[0];
		String city =aa[1];
		int  sal = Integer.parseInt(aa[2]);
		int  age = Integer.parseInt(aa[3]);
		System.out.println("happy birthday!" +name);
		System.out.println("from " +city);

		if(sal>=125000)
		{
			System.out.println("grade A");
		}
		else if((sal>50000) && (sal<125000))
		{
			System.out.println("grade B");
		}
		else if((sal>25000)&& (sal<=50000))
		{
			System.out.println("grade C");
		}else
		{
			System.out.println("grade D");
		}
		for(int j=0;j<5;j++)
		{
			System.out.println("j =" +j);
		}
	}
}


