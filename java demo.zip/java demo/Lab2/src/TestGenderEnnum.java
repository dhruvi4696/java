import java.util.Scanner;

public class TestGenderEnnum {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		GenderEnnum s1 = new GenderEnnum();
		s1.setFirstName("dhruvi");
		s1.setLastName("doshi");
		System.out.println("Enter phone num");
		int phn = sc.nextInt();
		s1.setPhoneNum(phn);
		System.out.println(" student first name : " +s1.getFirstName()+" Student last name : " + s1.getLastName()+" Gender : " +Gender.M+" salary : " +s1.getPhoneNum());
		
		MainPersonDetails s2 = new MainPersonDetails();
		s2.setFirstName("darsh");
		s2.setLastName("doshi");
		System.out.println("Enter phone num");
		int phn2 = sc.nextInt();
		s2.setPhoneNum(phn2);
		System.out.println(" student first name : " +s2.getFirstName()+" Student last name : " + s2.getLastName()+" Gender : " +Gender.F+" salary : " +s2.getPhoneNum());
		
		MainPersonDetails s3 = new MainPersonDetails();
		System.out.println(" student first name : " +s3.getFirstName()+" Student last name : " + s3.getLastName()+" Gender : " +" salary : " +s3.getPhoneNum());	
	}
}

