
public class TestAllEmpArrayDemo
{
	public static void main(String[] args)
	{
		Emp emps[]= new Emp[6];
		
		emps[0]= new Emp(111, "dhruvi" ,1000.0F);
		emps[1]= new WageEmp(222, "dhrashti" ,1000.0F,7,700);
		emps[2]= new SalsMgr(333, "priyanka" ,1000.0F,9,1000, 6900, 7.8F);
		emps[3]= new Emp(444, "darsh" ,1000.0F);
		emps[4]= new WageEmp(555, "janvi" ,1000.0F,9,3000);
		emps[5]= new SalsMgr(666, "jay" ,1000.0F,6,500,4566,8);
		
		for(int i=0;i<emps.length; i++ )
		{
			System.out.println(i+"  th Emp Info : "+emps[i].dispInfo() );
			System.out.println("Annual salary : "+emps[i].calcAnnualsal() );
			
			if (emps[i] instanceof SalsMgr)
			{
				System.out.println(i+" is employee"+"\n");
			}
			else if (emps[i] instanceof WageEmp)
			{
				System.out.println(i+" is wage employee"+"\n");
			}
			else
			{
				System.out.println(i+" is sales manager"+"\n");
			}
		}
	}
}
