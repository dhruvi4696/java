package com.emp.service;

import com.emp.bin.EmployeeBean;
import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{
	private EmployeeDao employeedao = new EmployeeDaoImpl();

	@Override
	public int addEmp(EmployeeBean bean) throws EmployeeException 
	{
		int id= employeedao.addEmp(bean);
		return id;
	}
}
