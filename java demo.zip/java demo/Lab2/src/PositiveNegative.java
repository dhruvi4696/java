import java.util.Scanner;

//2.2: Write a program to accept a number from user as a command line argument and check whether the given number is positive or negative number.

class Calculation
{
	int num;
	public void CalPosNegt(int number)
	{
		num = number;
		if(num>0)
		{
			System.out.println(num +" is positive");
		}
		else
		{
			System.out.println(num +" is negative");
		}
	}
}

public class PositiveNegative {
	public static void main(String[] args) 
	{
		Calculation obj1 =new Calculation();
		obj1.CalPosNegt(78);
	}
}
