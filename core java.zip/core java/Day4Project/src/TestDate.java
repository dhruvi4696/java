import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDate {

	public static void main(String[] args) {
			LocalDate today=LocalDate.now();
			System.out.println("Today is : " +today);
		
		LocalDateTime today1=LocalDateTime.now();
		System.out.println("Date and Time is : " +today1);
		
		System.out.println("My date of joining");
		LocalDate myDoj= LocalDate.of(2013, 4, 3);
		System.out.println("My Date of Joining : "+myDoj);
		
		System.out.println(" Date after 2 days : "+today.plusDays(2));
		
		Period per=Period.between(myDoj, today);
		
		System.out.println(" My Experience in CG is : " +per.getYears() +" Years "+per.getMonths()
				+" Months "+per.getDays() + " Days");
		
		String myDOBS = "10-dec-2013";
		DateTimeFormatter myFormatter= DateTimeFormatter.ofPattern("dd-mm-yyyy");
		
		LocalDateTime myDOB = LocalDateTime.parse(myDOBS,myFormatter);
		System.out.println(" My Date of Birth : " +myDOB.format(myFormatter));
	}

}
