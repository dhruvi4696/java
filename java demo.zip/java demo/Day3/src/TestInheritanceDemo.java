//inheritance and overriding demo

public class TestInheritanceDemo {

	public static void main(String[] args) 
	{
		Emp dhruvi = new Emp(111, "dhruvi d", 100.0F);
		WageEmp sameer = new WageEmp(222,"sammer k",10, 5,10);
		Emp mauli = new WageEmp(333,"mauli H",10, 8,4);  
		SalsMgr vibha = new SalsMgr(444,"Vibha D",70, 8,7,9000,1.0F);
		   
		System.out.println(dhruvi.dispInfo());
		System.out.println(sameer.dispInfo());
		System.out.print("\n");
		
		System.out.println("annual salary of dhruvi is :"+dhruvi.calcAnnualsal());
		System.out.print("\n");
		
	    System.out.println("annual salary of sameer is :"+sameer.calcAnnualsal()); 
	    System.out.print("\n");
		
	    System.out.println(mauli.dispInfo());
	    System.out.println("annual salary of mauli is :"+mauli.calcAnnualsal());
	    System.out.print("\n");
		
	    System.out.println(vibha.dispInfo());
	    System.out.print("annual salary of vibha is :"+vibha.calcAnnualsal());
	 }
}
