package com.test;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.Vector;

public class TestCollection 
{
	public static void main(String[] args) 
	{
		Collection list = new TreeSet();
		
		list.add("orange");
		list.add("apple");
		list.add("banana");
		list.add("chikoo");
		boolean b=list.add("apple");//true or false(can add or not)
		System.out.println(b);
		
		//list.add(0,"banana");
		
		/*int arraySize=list.size();
		System.out.println(" size = "+arraySize);
		String obj =(String) list.get(0);
		System.out.println(obj);
		list.clear();*/
		
		/*1-will not work in collection->array list ...its based on index.
		for(int i=0; i<list.size();i++)
		{
			System.out.println(list.get(i));
		}
		System.out.println("**********");
		*/
		
		
		//2
		for(Object obj : list)
		{
			String str= (String)obj;//type cast to string to get all behavior of string class.
			System.out.println(str);
			System.out.println("length: "+str.length()+"\n");
		}
		System.out.print("**********\n");
		
		
		//3-how to print
		Iterator ite=list.iterator();
		while(ite.hasNext())
		{
		Object obj=ite.next();
		System.out.println(obj);
		}
		System.out.println("**********");
		
		
		//4-what to print
		list.forEach(p->System.out.println(p));
	}
}
