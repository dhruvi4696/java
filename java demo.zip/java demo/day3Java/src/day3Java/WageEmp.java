
public class WageEmp {

}
