
public class TestEmployee {
	public static void main(String args[])
	{	
		Employee obj = new Employee("dhruvi", 1, 'F', 25000);
		System.out.println(obj.dispDetail() );
		
		Employee obj2 = new Employee();
		System.out.println(obj2.dispDetail() );
	}
}
