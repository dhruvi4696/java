import java.util.Scanner;

public class TestPersonDemo 
{
	public static void main(String args[])
	{
		Date vDOB = new Date(12,01,1997);
		Date aDOB = new Date(22,07,1988);
		
		Person veena = new Person ("CHB7990","Veena K", 7000.0F,vDOB);
		Person abhi = new Person ("HI69878","Abhishek P", 9000.0F,aDOB);
		
		System.out.println(" " + veena);//implicitly call the toString() function.
		System.out.println(" " + abhi.dispPersonInfo());
		
		Person pranita = new Person("JIHNUJ97","Pranita",18000.0F, aDOB,Gender.F);
		
		String ge= new Scanner(System.in).next();
		Gender gen = Gender.valueOf(ge);
		
		Person pranita = new Person("JIHNUJ97","Pranita",18000.0F, aDOB,gen);
		
		//override toString() to get info. of pranita 
		System.out.println( pranita);
		
	}
}



