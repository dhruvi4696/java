import java.util.Scanner;

public class ScannerArray {
		public static void main(String[] args)
		{
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter the size: ");
			int size= sc.nextInt();
			
			Person pers[]= new Person[size];
			for(int i=0;i<pers.length;i++)
			{
				System.out.print("Enter person name: ");
				String pernm = sc.next();
				
				System.out.print("Enter person pan no: ");
				String perpan = sc.next();
				
				System.out.print("Enter person birth date: ");
				int perdt= sc.nextInt();	
				
				System.out.print("Enter person birth month: ");
				int permnt= sc.nextInt();	
				
				System.out.print("Enter person birth year: ");
				int peryr= sc.nextInt();	
				
				System.out.print("Enter person salary: ");
				float persal= sc.nextFloat();
				
				Date dob = new Date(perdt, permnt, peryr); 
				pers[i] = new Person(perpan,pernm, persal, dob );
			}
			for(int i=0;i<pers.length;i++)
			{
				System.out.println("Person["+i+"]" + pers[i].dispPersonInfo());
				
			}
			sc.close();
		}
	}


