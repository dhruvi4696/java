
public class Syrup extends Medicines
{

	String type;
	public Syrup(){
		super();
	}
	
	
	public Syrup(String medName, String cmpName, String expDate, float price,
			String type) 
	{
		super(medName, cmpName, expDate, price);
		this.type= type;
	}
	
	public String dispInfo()
	{
		return super.dispInfo()
		+  "\ntype : "+type+"\nshake well before use! ";
	}
}
