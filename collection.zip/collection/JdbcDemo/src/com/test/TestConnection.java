package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestConnection 
{
	public static void main(String[] args)
	{
		//1.load and register driver
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver register success");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String user ="system";
			String pass="orcl11g";

			//2.get connection
			Connection con=DriverManager.getConnection(url, user, pass);
			System.out.println("connection success");
			
			Statement stmt =con.createStatement();
			
			//3.create statement
			String qry= "select empid,empname,empsal from emp_tbl";
			ResultSet rs=stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt("empid");
				String name = rs.getString("empname");
				int salary = rs.getInt("empsal");
				System.out.println(id +" "+ name +" "+salary );
			}
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			System.out.println("Driver not found");
		} 
		catch (SQLException e) 
		{	
			e.printStackTrace();
			System.out.println(e);
		}
	}
}
