
public class TestCastingDemo 
{
	public static void main(String args[])
	{
		Emp e1= null;
		e1= new Emp(1,"darsh", 100);
		WageEmp e2= new WageEmp(2, "dhruvi",1900, 8,800);
		SalsMgr e3  = new SalsMgr(3, "sanjay",1900.0F, 8,700,5000,8.0F);
		Emp  e4= new WageEmp(4, "janvi",1900, 8,700);
		Emp e5= new SalsMgr(5, "janvi",1900, 8,700,7000, 9.1F);
		WageEmp e6 = new SalsMgr (6, "janvi",1900, 8,700,7000, 9.1F);
		
		e2= (WageEmp)e4;
		System.out.println(e2.calcAnnualsal());
		
		if(e1 instanceof Emp)
		{
			System.out.println("yes e1 is emp");			
		}
		
		else
		{
			System.out.println("no, e1 is not emp");			
		}

		if(e1 instanceof SalsMgr)
		{
			System.out.println("yes e1 is sales manager");			
		}
		
		else
		{
			System.out.println("no, e1 is not sales manager");			
		}
		
		//e2= (WageEmp)e1;
		//System.out.println(e2.calcAnnualsal());
		
		
	}

}
