
public class SavingAccount extends AccountDemo
{
	final double overdraftLimit= 20000;
	public SavingAccount() 
	{
		super();
	}

	public SavingAccount(long accNum, String perName, double balance)
	{
		super(accNum, perName, balance);
	}

	@Override
	public void withdraw(double withdrawAmt)
	{
		if(( withdrawAmt>overdraftLimit)&& (balance-withdrawAmt)>20000)
		{
			double updatedBal=balance ; 
			System.out.println("Your updated balance is :"+ updatedBal+"\n");
		}
		else
        {
			System.out.println("You have reached overdraft limit!");
		}
	}

}
