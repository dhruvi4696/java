public class TestDateDemo {
	public static void main(String args[])
	{
		Date doj=null; 
		doj =new Date(9,8,9);
		//doj.setDate(25,11,2017);
		System.out.println("my doj is : "+doj.dispDate() );
		
		Date doj3 = new Date(9,9,16);
		//Date doj2 = new Date();
		//doj2.setDate(05,10,2016);
		System.out.println("your doj is : "+doj3.dispDate() );
		
		Date doj2 = new Date();
		System.out.println("unknown : "+doj2.dispDate() );
	}

}
