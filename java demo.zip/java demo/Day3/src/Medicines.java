

public class Medicines 
{

	 String medName;
	 String cmpName;
	 String expDate;
	 float price;
	
	public Medicines()
		{ }
	
	
	
	public Medicines(String medName, String cmpName, String expDate,
			float price)
	{
		this.medName = medName;
		this.cmpName = cmpName;
		this.expDate = expDate;
		this.price = price;
	}
	public String dispInfo()
	{
		return "medicine name is : "+ medName +"\ncompany : "+ cmpName +"\nexpiary date : "+expDate +"\nprice: " +price;
	}
}
