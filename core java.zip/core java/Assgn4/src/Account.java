/* 4.1: Refer the case study 1in Page No: 5 and create Account Class
as shown below in class diagram. 
Ensure minimum balance of INR 500 in a bank account is available. 
a) Create Account for smith with initial balance as INR 2000 and
    for Kathy with initial balance as 3000.(accNum should be auto generated).
b) Deposit 2000 INR to smith account.
c) Withdraw 2000 INR from Kathy account.
d) Display updated balances in both the account.
e) Generate toString() method */

public class Account extends Person
{
	long accNum;
	double balance;
	double newBalance=balance;
	
	
	public Account() {
		super();
	}
	public Account(String name, int age,double balance, long accNum) 
	{
		super(name, age);
		this.balance= balance;
		this.accNum=accNum;
		
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double withdraw(double num)
	{
		if(balance>500 && balance >num)
		{
			newBalance = balance-num;
		}
		else
		{
			newBalance=balance;
			System.out.println("insufficient balance");
		}
		return newBalance;
	}
	
	public double deposit(double num)
	{
		if(num<10000 && balance>num)
		{
			newBalance = balance+num;
		}
		else
		{
			newBalance=balance;
			System.out.println("overdraft limit reached!");
		}
		return newBalance;
	}

	public String toString()
	{
		return super.toString()+"Account number " 
				+(long) Math.floor(Math.random() * 9_000_000_000L)+" ,"
				+ " updated balance is : "+newBalance;
	}
}
