package com.test;

public class Employee implements Comparable
{
		private int empId;
		private String empname;
		private int empSal;
		
		public Employee(int empId, String empname, int empSal) {
			super();
			this.empId = empId;
			this.empname = empname;
			this.empSal = empSal;
		}
		
		public Employee()
		{
			super();
		}

		public int getEmpId() {
			return empId;
		}

		public void setEmpId(int empId) {
			this.empId = empId;
		}

		public String getEmpname() {
			return empname;
		}

		public void setEmpname(String empname) {
			this.empname = empname;
		}

		public int getEmpSal() {
			return empSal;
		}

		public void setEmpSal(int empSal) {
			this.empSal = empSal;
		}
		

		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", empname=" + empname
					+ ", empSal=" + empSal + "]";
		}

		@Override
		public int compareTo(Object obj) 
		{
			Employee emp= (Employee) obj;
			//int n=this.empId-emp.empId;
			int n=this.empname.compareTo(emp.empname);
			return n;
		}
}
