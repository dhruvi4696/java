
public class TestStudent {
	public static void main(String args[]){
		Student s1 = new Student();
		s1.setRollNo(453);
		s1.setsName("dhruvi");
		s1.setMarks(67);
	
		Student s2 = new Student();
		s2.setRollNo(897);
		s2.setsName("darsh");
		s2.setMarks(90);
		
		System.out.println(" roll no : " +s1.getRollNo()+" Student name : " + s1.getsName()+" U got : " +s1.getMarks());
	
		System.out.println(" roll no : " +s2.getRollNo()+" Student name : " + s2.getsName()+" U got : " +s2.getMarks());
		
	}

}
