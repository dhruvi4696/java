
public class Ointment extends Medicines
{
	String type;
	public Ointment(){
		super();
	}
	
	
	public Ointment(String medName, String cmpName, String expDate, float price,
			String type) 
	{
		super(medName, cmpName, expDate, price);
		this.type= type;
	}
	
	public String dispInfo()
	{
		return super.dispInfo()
		+  "\ntype : "+type + "\nfor external use only!";
	}
}
