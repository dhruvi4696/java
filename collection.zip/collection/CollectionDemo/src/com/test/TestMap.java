package com.test;

import java.util.Collection;
import java.util.HashMap;

public class TestMap 
{
	public static void main(String[] args) 
	{
		HashMap<Integer,Employee> map;
		map= new HashMap<Integer,Employee>();
		Employee e1 = new Employee(2001, "john",9000);
		Employee e2 = new Employee(2003, "radha",8000);
		Employee e3 = new Employee(2002, "amar",9000);
		
		map.put(1,e1);
		map.put(2, e2);
		map.put(3, e3);
		if(map.containsKey(2))
		{
			Employee emp = map.get(2);
			System.out.println(emp.getEmpname());
		}
		else
		{
			System.out.println("emp not found");
		}
		Collection<Employee> c= map.values();
		c.forEach(p->System.out.println(p));
	}
}
