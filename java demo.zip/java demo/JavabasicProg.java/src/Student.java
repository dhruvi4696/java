
public class Student {
	private int rollNo;
	private String sName;
	private int smarks;
	
	public Student()
	{
	}
	
	public int getRollNo()
	{
		return rollNo;
	}
	
	public void setRollNo(int rollNo)
	{
		this.rollNo= rollNo;
	}
	
	public String getsName()
	{
		return sName;
	}
	
	public void setsName(String sName)
	{
		this.sName= sName;
	}
	
	public int getMarks()
	{
		return smarks;
	}
	
	public void setMarks(int smarks)
	{
		this.smarks= smarks;
	}
}
