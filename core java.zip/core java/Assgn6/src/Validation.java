
public class Validation extends ExceptionEmployee
{
	public void Validate(String firstName)
	{
	if(firstName=="")
	{
		try
		{
			throw new InvalidFirstNameException("name can not be blank!");
		}
		catch(InvalidFirstNameException fe)
		{
			System.out.println(fe.getMessage());
		}
	}
	else
	{
		this.firstName= firstName;
	}
}
}

