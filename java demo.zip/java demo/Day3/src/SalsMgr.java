
public class SalsMgr extends WageEmp 
{

	int Sales;
	float commision;
	public SalsMgr()
	{
		super();
	}
	
	public SalsMgr(int empid, String  empName, float empSal , int noOfHrs, int ratePerHrs,int Sales,float commision) 
	{
		super(empid,empName, empSal,noOfHrs,ratePerHrs);
		this.Sales = Sales;
		this.commision= commision;
	}
	
	public String dispInfo()
	{
		return super.dispInfo()+
		 "\nsales manager [num of sales " + Sales +" ,commision"+commision +" ]";
	}
	
	public float calcAnnualsal()
	{
		return (super.calcAnnualsal())+((Sales*commision)/100);
	}
}
