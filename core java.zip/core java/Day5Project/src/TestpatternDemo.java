import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import com.sun.org.apache.xerces.internal.impl.xs.identity.Selector.Matcher;


public class TestpatternDemo 
{
	public static void main(String args[])
	{
		String str1 = "test string";
    	String str2="test string2";
		
    	boolean patternMethod = Pattern.matches(str2, str1);
    	System.out.println(patternMethod);
    	
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter name:");
    	String firstNm=sc.next();
    	String newpattern = "[A-Z][a-z]+";
    	
    	if(Pattern.matches(newpattern, firstNm))
    	{
    		System.out.println("hi "+firstNm);
    	}
    	else
    	{
    		System.out.println("enter valid name");
    	}
    	
    	String input ="Shop,Hop,Hopping,Choping";
    	Pattern pattern = Pattern.compile("hop");
    	Matcher matcher = pattern.matcher(input);
    	System.out.println("*******"+matcher.matches());
    	while(matcher.find())
    	{
    		System.out.println(matcher.group()+": "+matcher.start()+": "+matcher.end());
    	}
    sc.close();	
	}
}
