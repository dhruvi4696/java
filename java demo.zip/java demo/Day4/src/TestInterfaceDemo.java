
public class TestInterfaceDemo
{
	public static void main(String args[])
	{
		Printable p[]= new Printable[2];
		p[0]=new Customer(333,"harsh");
		p[1]=new Customer(444,"sanjay");
		
		Printable p1= new Customer (222,"dhruvi");
		Printable p2= new Customer (111,"darsh");
		p1.print();
		p2.print();
	}
}
