/*6.1: Modify the Lab assignment 2.3 to validate the full name of an employee.
Create and throw a user defined exception if firstName and lastName is blank.*/

import java.lang.Exception;
public class ExceptionEmployee
{
	String firstName;
	String lastName;
	char gender;
	 
	public ExceptionEmployee()
	{
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public void setFirstName(String firstName)
	{
		
	}
	public String getLastName()
	{
		return lastName;
	}
	
	public void setLastName(String lastName)
	{
		this.lastName= lastName;
	}
	
	public char getGender()
	{
		return gender;
	}
	
	public void setGender(char gender)
	{
		this.gender= gender;
	}

	@Override
	public String toString() {
		return "ExceptionEmployee [firstName=" + firstName + ", lastName="
				+ lastName + ", gender=" + gender + "]";
	}
	
	
}
