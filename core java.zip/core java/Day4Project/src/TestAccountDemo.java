import java.util.Scanner;


public class TestAccountDemo
{
	public static void main(String args[])
	{
		try(Scanner sc = new Scanner(System.in))
		{
		int currentBal = 50000;
		System.out.println("enter withdraw ammount: ");
		int withdrawAmt =sc.nextInt();
		if( withdrawAmt>currentBal)
		{
			try
			{
				throw new LowBalanceException("insufficient bal");
			}
			catch(LowBalanceException e)
			{
				System.out.println(e.getMessage());// e
			}
		}
		else
        {
			System.out.println("you have sufficient balance, u can with draw money");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
