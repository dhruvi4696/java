package com.test;

public class TestData
{
 public static void main(String[] args)
{
	 
	 Data<Integer> obj1 = new Data<Integer>();
	 Data<String> obj2 = new Data<String>();
	 Data<Employee> obj3 = new Data<Employee>();
	 
	 obj1.setData(100);
	 obj2.setData("john");
	 obj3.setData(new Employee());
	 Employee emp = obj3.getData();
	 System.out.println(emp);
	 
	 int i = obj1.getData();
	 System.out.println(i);
	 String str = obj2.getData();
	 System.out.println(str);
	 
	 /*
	 obj1.setData(100);
	 obj2.setData("john");
	 int i =(int) obj1.getData();
	 System.out.println(i);
	 String str =(String) obj2.getData();
	 System.out.println(str);
	 */ 
	 
}
}
