/*3.1: Create a method which can perform a particular String operation based on the user�s choice. 
 * The method should accept the String object and the user�s choice and 
 * return the output of the operation.
  Options are
 1.Add the String to itself
 2.Replace odd positions with #
 3.Remove duplicate characters in the String
 4.Change odd characters to upper case*/

import java.util.Scanner; 

public class StringOperation
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the string : ");
		String str = sc.next();
		
		System.out.println("1.add string to itself.\n2.Replace odd positions with #.\n3.Remove duplicate characters.\n4.");
		String type = sc.next();
	
		switch(type)
		{
		case "sm": 
		}
	}
}
