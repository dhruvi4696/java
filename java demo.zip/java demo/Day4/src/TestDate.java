import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;



public class TestDate {

	public static void main(String[] args)
	{
		LocalDate 
		//LocalDateTime today = LocalDateTime.now();
		System.out.println("date and time is : "+today);
		
		LocalDate doj = LocalDate(2013, 11, 13);
		System.out.println("date and time is : "+doj);
	}

}
