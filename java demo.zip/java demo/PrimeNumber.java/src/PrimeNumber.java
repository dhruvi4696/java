class Prime
{
  boolean PrimeCal(int n){
	for(int i=0; i<n;i++){
		
	}
	}
}

public class PrimeNumber {
	public static void main(String[] args) 
	{
		int num= Integer.parseInt(args[0]);
		Prime obj1 =new Prime();
		
	}
}
