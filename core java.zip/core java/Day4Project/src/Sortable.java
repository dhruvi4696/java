
public interface Sortable 
{
	public Sortable sort(Sortable list[]);
}
