import com.cg.uas.stu.Student;
import com.cg.uas.bat.Batch;

public class TestStuPack
{
	public static void main(String[] args)
	{
		Batch javaBatch = new Batch("JEE_ABRIDGED","8.30 AM to 7.30 PM","Dhruvi Doshi");
		Batch testingBatch = new Batch("TESTING","9.00 AM to 6.30 PM","Nehal Parikh");
		
		Student tripti = new Student (1234,"Tripti" , javaBatch);
		Student harsh = new Student (5678,"Harsh" , testingBatch);
		
		System.out.println("*********All Batch info**********");
		System.out.println(tripti.dispStuInfo());
		System.out.println(harsh.dispStuInfo());
		
		
	}
}
