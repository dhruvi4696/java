package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emp.bin.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao
{
	public int generateEmployeeId()
	{
		int id=0;
		Connection  con = DBConnection.getConnection();
		String str= "select empid_seq.nextval from dual";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return id;
	}
	
	@Override
	public int addEmp(EmployeeBean bean) throws EmployeeException
	{
		int id=0;
		Connection con= DBConnection.getConnection();
		String cmd="insert into emp_tbl(empid,empname,empsal) values(?,?,?)";
		
		try {
			 id=generateEmployeeId();
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1,id);
			ps.setString(2,bean.getEmployeeName());
			ps.setInt(3, bean.getEmployeesalary());
			
			int n=ps.executeUpdate();
			System.out.println(n);
		}
		catch (SQLException e) 
		{
			throw new EmployeeException("unable to insert");
		}
		return id;
	}
}
