/* 2.3: Refer the class diagram given below and createa personclass.
 Create default and parameterized constructor for Person class.
 Also Create �PersonMain.java� program and write code for following operations:
a) Create an object of Person class and specify person details through constructor.
b) Display the details in the format given in Lab assignment 2.1 */

public class PersonMain {
	 String firstName;
	 String lastName;
	 char gender;
	
	public PersonMain()
	{
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public void setFirstName(String firstName)
	{
		this.firstName= firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public void setLastName(String lastName)
	{
		this.lastName= lastName;
	}
	
	public char getGender()
	{
		return gender;
	}
	
	public void setGender(char gender)
	{
		this.gender= gender;
	}
}
