package com.test;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.Vector;


public class TestCollectionDemo2 
{

	public static void main(String[] args) 
	{
		ArrayList list= new ArrayList();
		
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(5);
		
		
		Collections.sort(list);
		Collections.reverse(list);
		Collections.shuffle(list);
		

		Iterator ite=list.iterator();
		while(ite.hasNext())
		{
		Object obj=ite.next();
		System.out.println(obj);
		}
		System.out.println("**********");
		
		list.forEach(p->System.out.println(p));

	}

}
