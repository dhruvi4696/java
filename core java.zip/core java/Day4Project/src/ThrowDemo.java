import java.io.IOException;

public class ThrowDemo 
{
	public void method1() throws IOException 
	{
		System.out.println("I am in method 1 of throw demo.");
		method2();
	}
	public void method2() throws IOException
	{
		System.out.println("I am in method 2 of throw demo.");
		throw new IOException();
		/*try
		{
			throw new IOException();
		}
		catch (IOException ie)
		{
			System.out.println("in IO Exception");
			ie.printStackTrace();
		}*/
	}	
}
