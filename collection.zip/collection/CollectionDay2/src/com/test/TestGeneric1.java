package com.test;

import java.util.ArrayList;

public class TestGeneric1
{
	public static void main(String[] args) 
	{
		ArrayList<? extends Number> list = new ArrayList();
		
	}
}
