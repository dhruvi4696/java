
public class TestEqualsDemo 
{
	public static void main(String args[]) 
	{
		Integer i1 = new Integer(10);
		Integer i2 = new Integer(20);
		Integer i3 = new Integer(10);
		
		if(i1.equals(i2))
		{
			System.out.println("Equals");
			System.out.println("hashcode of i1: "+i1.hashCode());
			System.out.println("hashcode of i2: "+i2.hashCode());
			System.out.println("hashcode of i3: "+i3.hashCode());
		}
		else
		{
			System.out.println("Not Equals");
			System.out.println("hashcode of i1: "+i1.hashCode());
			System.out.println("hashcode of i2: "+i2.hashCode());
			System.out.println("hashcode of i3: "+i3.hashCode());
		}
		
		System.out.println("\n***string comparison***");
		String str1 = "Capgemini";
		String str2 = new String("iGate");
		String str3 = "Ltd";
		String str5 = "Capgemini";
		String str4 = new String("Capgemini");
		StringBuffer city = new StringBuffer("Pune");
		
		System.out.println("hashcode of str1: "+str1.hashCode());
		System.out.println("hashcode of str2: "+str2.hashCode());
		System.out.println("hashcode of str3: "+str3.hashCode());
		System.out.println("hashcode of str4: "+str4.hashCode());
		System.out.println("hashcode of str5: "+str5.hashCode());
		System.out.println("hashcode of city: "+city.hashCode());

		System.out.println("Is str1 == str2 : "+(str1==str2));
		System.out.println("Is str1 == str2 : "+(str1==str4));
		System.out.println("Is str1 == str2 : "+(str1==str5));
		System.out.println("Is str1 equals str2 : "+(str1.equals(str2)));
		System.out.println("Is str1 equals str4 : "+(str1.equals(str4)));
		System.out.println("Is str1 equals str5 : "+(str1.equals(str5)));
			
	}
}
