import java.util.Scanner;

public class Scanner1 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size: ");
		int size= sc.nextInt();
		
		Emp emps[]= new Emp[size];
		for(int i=0;i<size;i++)
		{
			System.out.print("Enter Emp id: ");
			int eid = sc.nextInt();
			
			System.out.print("Enter Emp name: ");
			String enm = sc.next();
			
			System.out.print("Enter Emp salary: ");
			float esl = sc.nextFloat();	
			System.out.print("\n");
			emps[i]= new Emp(eid, enm, esl);
		}
		
		for(int i=0;i<size;i++)
		{
			System.out.println(i +"th Details " +emps[i].dispInfo());
			System.out.println(i +" Annual salary is " +emps[i].calcAnnualsal());
		}
		sc.close();
	}
}
