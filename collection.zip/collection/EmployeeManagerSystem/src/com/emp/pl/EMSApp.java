package com.emp.pl;

import java.util.Scanner;

import com.emp.bin.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImpl;

public class EMSApp 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter employee name: ");
		String name = sc.next();
		System.out.println("enter employee salary: ");
		int salary = sc.nextInt();
		
		EmployeeBean bean = new EmployeeBean();
		bean.setEmployeeName(name);
		bean.setEmployeesalary(salary);
		EmployeeService service = new EmployeeServiceImpl();
		
		try {
			int n = service.addEmp(bean);
			System.out.println("employee added! id = "+n);
		} 
		catch (EmployeeException e) 
		{	
			e.printStackTrace();
		}
	}
}
