
public class Employee {
	String name;
	int id;
	char gen;
	float sal;
	
	//empty const.
	public Employee(){
		sal=0;
		id=0;
		gen= ' ';
		name=" ";	
	}
	
	public Employee(String nm, int idd, char gn,float sl)
	{
		//local variable
		name=nm;
		id=idd;
		sal=sl;
		gen=gn;
	}
	
	public String dispDetail()
	{
		return name+"'s id is "+id+", salary is  "+sal +" and gender is "+gen;
	}
}
