import java.util.Scanner;
import java.util.TimeZone;

/* 3.6: Create a method which accept zone id and print the current date and time with respect to
given zone. (Hint: Few zones to test your code. America/New_York, 
Europe/London, Asia/Tokyo, US/Pacific, Africa/Cairo, Australia/Sydney etc.) */

public class DateFromZoneId 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);	
		System.out.print("Enter zone id: ");
		String zoneid = sc.next();	
		TimeZone zone = TimeZone.getTimeZone(zoneid);
		System.out.println("The current time zone is :"+ zone);
		sc.close();
	}
}

