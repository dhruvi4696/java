import java.util.Scanner;


public class TestAccountPerson 
{
	public static void main(String[] args) 
	{
	
	Account smith= new Account();
	Account kathya = new Account();
	smith.setAge(21);
	smith.setName("smith");
	
	smith.setAge(20);
	smith.setName("kathya");
	
	Scanner sc = new Scanner(System.in);
	
	smith.setBalance(2000.0);
	kathya.setBalance(3000.0);
	
	
	System.out.println("enter amount to deposit for smith");
	int num = sc.nextInt();
	smith.deposit(num);
	System.out.println(smith);
	
	System.out.println("enter amount to withdraw for kathya");
	int num1 = sc.nextInt();
	kathya.withdraw(num1);
	System.out.println(kathya);
	sc.close();
	}
}