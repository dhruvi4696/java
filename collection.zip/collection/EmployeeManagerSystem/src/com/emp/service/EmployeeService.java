package com.emp.service;

import com.emp.bin.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeService 
{
	public int addEmp(EmployeeBean bean) throws EmployeeException;
}
