import java.util.Scanner;

public class ScannerPerson {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
			
			System.out.print("Enter person name: ");
			String pernm = sc.next();
			
			System.out.print("Enter person pan no: ");
			String perpan = sc.next();
			
			System.out.print("Enter person birth date: ");
			int perdt= sc.nextInt();	
			
			System.out.print("Enter person birth month: ");
			int permnt= sc.nextInt();	
			
			System.out.print("Enter person birth year: ");
			int peryr= sc.nextInt();	
			
			System.out.print("Enter person salary: ");
			float persal= sc.nextFloat();
			
			Date dob = new Date(perdt, permnt, peryr); 
			Person pers = new Person(perpan,pernm, persal, dob );
			
			System.out.print("Enter person name: ");
		   pernm = sc.next();
			 
			System.out.print("Enter person pan no: ");
			perpan = sc.next();
			
			System.out.print("Enter person birth date: ");
		   perdt= sc.nextInt();	
			
			System.out.print("Enter person birth month: ");
			 permnt= sc.nextInt();	
			
			System.out.print("Enter person birth year: ");
		    peryr= sc.nextInt();	
			
			System.out.print("Enter person salary: ");
		    persal= sc.nextFloat();
			
			Date dob1 = new Date(perdt, permnt, peryr); 
			Person pers1 = new Person(perpan,pernm, persal, dob );
			System.out.println("First Person : " + pers.dispPersonInfo());
			System.out.println("First Person : " + pers1.dispPersonInfo());
			
			sc.close();
	}
}
