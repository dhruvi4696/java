
public class TestArrayDemo {
	public static void main(String args[])
	{
		int markArr[]= new  int[4];
		markArr[0] = 90;
		markArr[1] = 80;
		markArr[2] = 75;
		markArr[3] = 65;
		
		for(int i=0;i<markArr.length;i++)
		{
			System.out.println("markArr["+i+"]: " + markArr[i]);
		}
			System.out.println("*****cities*****");
			String[] cityList ={"Pune" ,  "Mumbai" , "Noida", "Banglore"};
			
			for(int i=0;i<cityList.length;i++)
			{
				System.out.println("cityList["+i+"]: " + cityList[i]);
			}
			
			
			System.out.println("*****2D array*****");
			int A[][]=new int[3][2];
			A[0][0]=9;
			A[0][1]=9;
			A[1][0]=9;
			A[1][1]=9;
			A[2][1]=9;
			A[2][0]=9;
			
			for(int k=0;k<A.length;k++)
			{
				for(int j=0;j<A[k].length;j++)
				{
				System.out.println(" " + A[k][j]);
				}
				System.out.println();
			}
	}
}
